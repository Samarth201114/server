# server.py
from flask import Flask, render_template_string, request, jsonify
from flask_socketio import SocketIO, emit
import eventlet
eventlet.monkey_patch()

app = Flask(__name__)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='eventlet')

# Keep track of device_id -> sid, and sid -> device_id
device_by_sid = {}
sids_by_device = {}

html_page = """
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Mini Comm Server</title>
  <style>
    body { font-family: Arial, sans-serif; background:#0f1720; color:#e6eef8; padding:20px; }
    .row{margin-bottom:10px;}
    select,input,button { padding:10px; border-radius:6px; border: none; }
    select,input{ width:60%; }
    button{ background:#06b6d4; color:#04202b; cursor:pointer; }
    #log{ background:#071023; padding:12px; border-radius:8px; height:320px; overflow:auto; }
    .small { font-size:0.9em; color:#9fb6c9; }
  </style>
</head>
<body>
  <h2>📡 Mini Communication Server</h2>
  <div class="small">Connected devices: <span id="count">0</span></div>
  <div id="log"></div>

  <div class="row">
    <select id="target"><option value="__all">Broadcast (All)</option></select>
  </div>
  <div class="row">
    <input id="msg" placeholder="Type command or message...">
    <button onclick="send()">Send</button>
  </div>

<script src="https://cdn.socket.io/4.7.2/socket.io.min.js"></script>
<script>
  const socket = io();

  socket.on('connect', () => { log('[system] connected to server'); });

  socket.on('device_list', data => { updateDeviceList(data); });

  socket.on('message', data => { log('📩 '+JSON.stringify(data)); });

  function send(){
    const msg = document.getElementById('msg').value.trim();
    const target = document.getElementById('target').value;
    if(!msg) return;
    const payload = { from: 'phone', to: target, message: msg };
    socket.emit('send_message', payload);
    log('📤 you -> '+target+': '+msg);
    document.getElementById('msg').value = '';
  }

  function log(t){
    const box = document.getElementById('log');
    box.innerHTML += t + '<br>';
    box.scrollTop = box.scrollHeight;
  }

  function updateDeviceList(list){
    const sel = document.getElementById('target');
    sel.innerHTML = '<option value="__all">Broadcast (All)</option>';
    for(const d of list){
      const opt = document.createElement('option');
      opt.value = d;
      opt.innerText = d;
      sel.appendChild(opt);
    }
    document.getElementById('count').innerText = list.length;
  }

  socket.emit('query_devices', {});
</script>
</body>
</html>
"""

@app.route('/')
def index():
    return render_template_string(html_page)

@app.route('/devices', methods=['GET'])
def get_devices():
    return jsonify(sorted(list(sids_by_device.keys())))

@app.route('/send', methods=['POST'])
def http_send():
    j = request.get_json(force=True)
    to = j.get('to')
    msg = j.get('message')
    frm = j.get('from', 'http-client')
    payload = {'from': frm, 'to': to, 'message': msg}
    if to == '__all' or to is None:
        socketio.emit('message', payload)
        return jsonify(status='ok', broadcast=True)
    sid = sids_by_device.get(to)
    if sid:
        socketio.emit('message', payload, to=sid)
        return jsonify(status='ok', to=to)
    return jsonify(status='error', reason='target_offline'), 404

@socketio.on('connect')
def on_connect(): print('client connected', request.sid)

@socketio.on('disconnect')
def on_disconnect():
    sid = request.sid
    device = device_by_sid.pop(sid, None)
    if device:
        sids_by_device.pop(device, None)
        socketio.emit('device_list', sorted(list(sids_by_device.keys())))

@socketio.on('register')
def on_register(data):
    sid = request.sid
    device = str(data.get('device'))
    device_by_sid[sid] = device
    sids_by_device[device] = sid
    emit('device_list', sorted(list(sids_by_device.keys())), broadcast=True)

@socketio.on('send_message')
def on_send_message(payload):
    to = payload.get('to')
    frm = payload.get('from', device_by_sid.get(request.sid, 'unknown'))
    msg = payload.get('message')
    out = {'from': frm, 'to': to, 'message': msg}
    if to == '__all' or to is None:
        socketio.emit('message', out)
    else:
        sid = sids_by_device.get(str(to))
        if sid:
            socketio.emit('message', out, to=sid)
        else:
            emit('message', {'from':'server','to':frm,'message':f'target {to} offline'}, to=request.sid)

@socketio.on('query_devices')
def handle_query(_):
    emit('device_list', sorted(list(sids_by_device.keys())))

if __name__=='__main__':
    socketio.run(app, host='0.0.0.0', port=5000)
